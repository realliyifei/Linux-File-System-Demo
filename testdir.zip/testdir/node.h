#ifndef _NODEH_
#define _NODEH_

typedef struct node {
	char *filepath;
	struct node* next;
} node;

#endif
